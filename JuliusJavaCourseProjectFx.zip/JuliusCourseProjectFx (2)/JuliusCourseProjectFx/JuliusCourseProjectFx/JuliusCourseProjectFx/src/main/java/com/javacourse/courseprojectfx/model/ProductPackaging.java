package com.javacourse.courseprojectfx.model;

public enum ProductPackaging {
    plastic_bag, plastic_box, paperboard_box
}
