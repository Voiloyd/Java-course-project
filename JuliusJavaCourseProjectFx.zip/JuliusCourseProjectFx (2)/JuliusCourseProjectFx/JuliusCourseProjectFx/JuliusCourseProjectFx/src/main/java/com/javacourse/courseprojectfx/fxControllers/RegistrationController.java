package com.javacourse.courseprojectfx.fxControllers;

import com.javacourse.courseprojectfx.HelloApplication;
import com.javacourse.courseprojectfx.hibernate.ShopHibernate;
import com.javacourse.courseprojectfx.model.Customer;
import com.javacourse.courseprojectfx.model.Manager;
import jakarta.persistence.EntityManagerFactory;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.stage.Stage;

import java.io.IOException;
import java.util.Objects;

public class RegistrationController {

    @FXML
    public TextField loginField;
    @FXML
    public PasswordField passwordField;
    @FXML
    public PasswordField repeatPasswordField;
    @FXML
    public TextField nameField;
    @FXML
    public TextField surnameField;
    @FXML
    public RadioButton customerCheckbox;
    @FXML
    public ToggleGroup userType;
    @FXML
    public RadioButton managerCheckbox;
    @FXML
    public TextField addressField;
    @FXML
    public TextField cardNoField;
    @FXML
    public DatePicker birthDateField;
    @FXML
    public TextField employeeIdField;
    @FXML
    public TextField medCertificateField;
    @FXML
    public DatePicker employmentDateField;
    @FXML
    public CheckBox isAdminCheck;
    @FXML
    public TextField billingAddressField;

    private EntityManagerFactory entityManagerFactory;

    public void setData(EntityManagerFactory entityManagerFactory, boolean showManagerFields) {
        this.entityManagerFactory = entityManagerFactory;
        disableFields(showManagerFields);
    }

    public void setData(EntityManagerFactory entityManagerFactory, Manager manager) {
        this.entityManagerFactory = entityManagerFactory;
        toggleFields(customerCheckbox.isSelected(), manager);
    }

    private void disableFields(boolean showManagerFields) {
        if (!showManagerFields) {
            employeeIdField.setVisible(false);
            medCertificateField.setVisible(false);
            employmentDateField.setVisible(false);
            isAdminCheck.setVisible(false);
            managerCheckbox.setVisible(false);
        }
    }

    private void toggleFields(boolean isManager, Manager manager) {
        if (isManager) {
            addressField.setDisable(true);
            cardNoField.setDisable(true);
            employeeIdField.setDisable(false);
            medCertificateField.setDisable(false);
            employmentDateField.setDisable(false);
            if (manager.isAdmin()) isAdminCheck.setDisable(false);
        } else {
            addressField.setDisable(false);
            cardNoField.setDisable(false);
            employeeIdField.setDisable(true);
            medCertificateField.setDisable(true);
            employmentDateField.setDisable(true);
            isAdminCheck.setDisable(true);
        }
    }
    public void createUser() {
        ShopHibernate shopHibernate = new ShopHibernate(entityManagerFactory);
        if (customerCheckbox.isSelected()) {
            if (isAllFieldSelected(false)) {
                if (!shopHibernate.isLoginUsed(loginField.getText())) {
                    Customer customer = new Customer(
                            nameField.getText(),
                            surnameField.getText(),
                            loginField.getText(),
                            passwordField.getText(),
                            cardNoField.getText(),
                            addressField.getText(),
                            billingAddressField.getText(),
                            birthDateField.getValue()
                    );
                    shopHibernate.create(customer);
                }
            }
        }
        if (managerCheckbox.isSelected()) {
            if (!shopHibernate.isLoginUsed(loginField.getText())) {
                if (isAllFieldSelected(true)) {
                    Manager manager = new Manager(
                            nameField.getText(),
                            surnameField.getText(),
                            loginField.getText(),
                            passwordField.getText(),
                            isAdminCheck.isSelected(),
                            employeeIdField.getText(),
                            medCertificateField.getText(),
                            employmentDateField.getValue()
                    );
                    shopHibernate.create(manager);
                }
            }
        }
    }

    private boolean isAllFieldSelected(boolean isManager){
        if(isManager){
            if(nameField.getText().trim().isEmpty())return false;
            if(surnameField.getText().trim().isEmpty()) return false;
            if(loginField.getText().trim().isEmpty()) return false;
            if(passwordField.getText().trim().isEmpty()) return false;
            if(employeeIdField.getText().trim().isEmpty()) return false;
            if(medCertificateField.getText().trim().isEmpty()) return false;
            if(employmentDateField.getValue()==null) return false;

        }
        else{
            if(nameField.getText().trim().isEmpty())return false;
            if(surnameField.getText().trim().isEmpty()) return false;
            if(loginField.getText().trim().isEmpty()) return false;
            if(passwordField.getText().trim().isEmpty()) return false;
            if(cardNoField.getText().trim().isEmpty()) return false;
            if(addressField.getText().trim().isEmpty()) return false;
            if(billingAddressField.getText().trim().isEmpty()) return false;
            if(birthDateField == null) return false;
        }
        return true;
    }
    public void registerRadioButtonSelect( ) {
        if(managerCheckbox.isSelected()){
            cardNoField.setDisable(true);
            addressField.setDisable(true);
            billingAddressField.setDisable(true);
            billingAddressField.setDisable(true);
            birthDateField.setDisable(true);
            employeeIdField.setDisable(false);
            medCertificateField.setDisable(false);
            isAdminCheck.setDisable(false);
            employmentDateField.setDisable(false);
        }
        if(customerCheckbox.isSelected()){
            cardNoField.setDisable(false);
            addressField.setDisable(false);
            billingAddressField.setDisable(false);
            billingAddressField.setDisable(false);
            birthDateField.setDisable(false);
            employeeIdField.setDisable(true);
            medCertificateField.setDisable(true);
            isAdminCheck.setDisable(true);
            employmentDateField.setDisable(true);
        }
    }

    public void returnToLogin() throws IOException {
        FXMLLoader fxmlLoader = new FXMLLoader(HelloApplication.class.getResource("login-form.fxml"));
        Parent parent = fxmlLoader.load();
        Stage stage = (Stage) loginField.getScene().getWindow();
        Scene scene = new Scene(parent);
        FxUtils.setStageParameters(stage, scene, false);
    }
}
