package com.javacourse.courseprojectfx.model;

import jakarta.persistence.Entity;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.time.LocalDate;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Entity
public final class Fruits extends Product {

    private LocalDate pickDate;
    private LocalDate plantDate;
    private LocalDate validTill;
    private String colour;
    private String type;



    public Fruits(String title, String type, String colour, String description, int qty, float weight, float price, LocalDate plantDate, LocalDate validTill) {
        super(title, type, colour, description, qty, weight,price);
        this.plantDate = plantDate;
        this.validTill = validTill;
        this.colour = colour;
        this.type = type;
    }

    @Override
    public String toString() {return title + ":" + qty;}
}
