package com.javacourse.courseprojectfx.model;

public enum IcecreamType {
    in_a_waffle, on_a_stick
}
