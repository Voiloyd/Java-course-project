package com.javacourse.courseprojectfx.model;

import jakarta.persistence.Entity;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Entity
public class IceCream extends Product {
    private String manufacturer;
    public IceCream(String title, String type, String colour, String description, int qty, float weight, float price, String manufacturer) {
        super(title, type, colour, description, qty, weight,price);
        this.manufacturer = manufacturer;
    }
    @Override
    public String toString() {
        return title + ":" + qty;
    }
}
