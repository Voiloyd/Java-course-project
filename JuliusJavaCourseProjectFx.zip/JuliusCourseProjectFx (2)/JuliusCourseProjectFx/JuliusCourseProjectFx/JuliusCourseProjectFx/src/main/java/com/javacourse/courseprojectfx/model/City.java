package com.javacourse.courseprojectfx.model;

public enum City {
    KLAIPEDA, VILNIUS, KAUNAS, PANEVEZYS, SIAULIAI
}
