package com.javacourse.courseprojectfx.fxControllers.tableParameters;

import javafx.beans.property.SimpleFloatProperty;
import javafx.beans.property.SimpleIntegerProperty;
import javafx.beans.property.SimpleStringProperty;

public class CartTableParameters {
    SimpleIntegerProperty id = new SimpleIntegerProperty();
    SimpleStringProperty title = new SimpleStringProperty();
    SimpleStringProperty type = new SimpleStringProperty();
    SimpleStringProperty colour = new SimpleStringProperty();
    SimpleFloatProperty price = new SimpleFloatProperty();

    public CartTableParameters() {
    }

    public CartTableParameters(SimpleIntegerProperty id, SimpleStringProperty title, SimpleStringProperty type, SimpleStringProperty colour, SimpleFloatProperty price) {
        this.id = id;
        this.title = title;
        this.type = type;
        this.colour = colour;
        this.price = price;
    }

    public int getId() {
        return id.get();
    }

    public SimpleIntegerProperty idProperty() {
        return id;
    }

    public void setId(int id) {
        this.id.set(id);
    }

    public String getTitle() {
        return title.get();
    }

    public SimpleStringProperty titleProperty() {
        return title;
    }

    public void setTitle(String title) {
        this.title.set(title);
    }

    public String getType() {
        return type.get();
    }

    public SimpleStringProperty typeProperty() {
        return type;
    }

    public void setType(String type) {
        this.type.set(type);
    }

    public String getColour() {
        return colour.get();
    }

    public SimpleStringProperty colourProperty() {
        return colour;
    }

    public void setColour(String colour) {
        this.colour.set(colour);
    }

    public float getPrice() {
        return price.get();
    }

    public SimpleFloatProperty priceProperty() {
        return price;
    }

    public void setPrice(float price) {
        this.price.set(price);
    }
}

