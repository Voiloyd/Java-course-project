package com.javacourse.courseprojectfx.model;

import com.javacourse.courseprojectfx.model.Comment;
import com.javacourse.courseprojectfx.model.PasswordHash;
import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import org.hibernate.annotations.LazyCollection;
import org.hibernate.annotations.LazyCollectionOption;

import java.io.Serializable;
import java.time.LocalDate;
import java.util.List;

@Entity
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public abstract class User implements Serializable{
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    protected int id;
    protected String name;
    protected String surname;
    @Column(unique = true)
    protected String login;
    protected String password;
    protected LocalDate dateCreated;
    protected LocalDate dateModified;
    @OneToMany(mappedBy = "owner", cascade = CascadeType.ALL)
    @LazyCollection(LazyCollectionOption.FALSE)
    protected List<Comment> comments;
    @Transient
    private String columnDoNotCreate;


    public User(String name, String surname, String login, String password) {
        this.name = name;
        this.surname = surname;
        this.login = login;
        this.password = PasswordHash.hashPassword(password) ;
        this.dateCreated = LocalDate.now();
    }
}
