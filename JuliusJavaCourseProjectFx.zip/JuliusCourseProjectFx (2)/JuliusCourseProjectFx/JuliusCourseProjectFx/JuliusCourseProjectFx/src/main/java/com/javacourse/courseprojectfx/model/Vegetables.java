package com.javacourse.courseprojectfx.model;

import jakarta.persistence.Entity;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.time.LocalDate;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Entity
public class Vegetables extends Product {
    private String farm;
    private LocalDate collectDate;
    private ProductPackaging productPackaging;

    public Vegetables(String title, String type, String colour, String description, int qty, float weight, float price, String farm, LocalDate collectDate, ProductPackaging productPackaging) {
        super(title, type, colour, description, qty, weight, price);
        this.farm = farm;
        this.collectDate = collectDate;
        this.productPackaging = productPackaging;
    }
    @Override
    public String toString() {
        return title + ":" + qty;
    }
}
