package com.javacourse.courseprojectfx.fxControllers;

public class LoginWindow {
}
