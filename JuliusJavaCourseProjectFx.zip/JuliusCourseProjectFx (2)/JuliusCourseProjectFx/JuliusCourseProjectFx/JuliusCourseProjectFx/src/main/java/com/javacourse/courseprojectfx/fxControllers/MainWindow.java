package com.javacourse.courseprojectfx.fxControllers;
import com.javacourse.courseprojectfx.HelloApplication;
import com.javacourse.courseprojectfx.fxControllers.tableParameters.CartTableParameters;
import com.javacourse.courseprojectfx.fxControllers.tableParameters.CustomerTableParameters;
import com.javacourse.courseprojectfx.fxControllers.tableParameters.ManagerTableParameters;
import com.javacourse.courseprojectfx.hibernate.GenericHibernate;
import com.javacourse.courseprojectfx.hibernate.ShopHibernate;
import com.javacourse.courseprojectfx.model.*;
import jakarta.persistence.EntityManagerFactory;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.event.Event;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.control.cell.TextFieldTableCell;
import javafx.stage.Modality;
import javafx.stage.Stage;
import javafx.util.Callback;
import java.io.IOException;
import java.net.URL;
import java.util.List;
import java.util.ResourceBundle;


//Jei norite prieiti prie laukų iki jie bus sugeneruoti, reikia, kad kontrolerio klasė implementuotų Initializable interfeisą
//Tuomet reikės implementuoti initialize() metodą, jo viduje matysite kaip užpildau combo box
public class MainWindow implements Initializable {
    //Aš dažniausiai susidedu @FXML prie visų klasės kintamųjų, kurie yra susieti su formos elementų id, lengviau būna dirbti
    @FXML
    //ListView be nieko yra taip vadinamasis raw usage of list view. Geriausia yra nurodyti kokio tipo duomenis mes saugosim tame sąraše
    //Šiuo atveju tai būtų Product
    public ListView<Product> shopProducts;
    @FXML
    public Tab shopTab;
    @FXML
    public ListView<Product> myCartItems;
    @FXML
    public Tab productsTab;
    @FXML
    public ListView<Product> productAdminList;
    @FXML
    public TextField productTitleField;
    @FXML
    public TextArea productDescriptionField;
    @FXML
    public TextField productQuantityField;
    @FXML
    public TextField productWeightField;
    @FXML
    public DatePicker productPlantDateField;
    @FXML
    public DatePicker productValidTillField;
    @FXML
    public TextField productColourField;
    @FXML
    public TextField productTypeField;
    @FXML
    public TextField productFarmField;
    @FXML
    public DatePicker productSeedPickDate;
    @FXML
    //Čia mano ComboBox saugos Enum SeedType reikšmes
    public ComboBox<ProductPackaging> productPackagingField;
    @FXML
    public TextField productManufacturerField;
    @FXML
    public RadioButton productFruitsRadio;
    @FXML
    public RadioButton productVegetablesRadio;
    @FXML
    public RadioButton productIceCreamRadio;
    @FXML
    public ComboBox<IcecreamType> icecreamTypeField;

    public TableColumn<ManagerTableParameters, Integer> managerColId;
    public TableColumn<ManagerTableParameters, String> managerColLogin;
    public TableColumn<ManagerTableParameters, String> managerColName;
    public TableColumn<ManagerTableParameters, String> managerColSurname;
    public TableColumn<ManagerTableParameters, String> managerColPassword;
    public TableView<ManagerTableParameters> managerTable;
    public ComboBox<City> warehouseCityField;
    public ListView<Warehouse> warehouseList;
    public TextField warehouseAddressField;
    public TableView <CartTableParameters> ordersTableView;
    public TableColumn <CartTableParameters, Integer> cartColId;
    public TableColumn <CartTableParameters, String> cartColTitle;
    public TableColumn <CartTableParameters, String> cartColType;
    public TableColumn <CartTableParameters, String> cartColColour;
    public TableColumn <CartTableParameters, String> cartColPrice;
    public TextField productPriceField;
    //public ComboBox<warehouseList> productWarehouseField;
    private ObservableList<CartTableParameters> datacart = FXCollections.observableArrayList();
    public DatePicker dateFrom;
    public DatePicker dateTo;
    public TextField customerId;
    public TextField managerId;
    public ListView<Cart> ordersListView;
    public ToggleGroup productType;
    private ObservableList<ManagerTableParameters> datamanager = FXCollections.observableArrayList();
    public TableColumn<ManagerTableParameters, Void> managerdummyCol;
    public TableView<CustomerTableParameters> customerTable;
    public TableColumn<CustomerTableParameters, Integer> customerColId;
    public TableColumn<CustomerTableParameters, String> customerColLogin;
    public TableColumn<CustomerTableParameters, String> customerColName;
    public TableColumn<CustomerTableParameters, String> customerColSurname;
    public TableColumn<CustomerTableParameters, String> customerColPassword;
   // public TableColumn<ManagerTableParameters, Void> dummyCol;
    private ObservableList<CustomerTableParameters> datacust = FXCollections.observableArrayList();
    public TableColumn<CustomerTableParameters, Void> customerdummyCol;
    public Tab usersTab;
    public TextField loginField;
    public PasswordField passwordField;
    //</editor-fold>

    public Tab ordersTab;
    public Tab warehousesTab;
    @FXML
    public TabPane tabPane;
    private EntityManagerFactory entityManagerFactory;
   // private EntityCustomerFactory entityCustomerFactory;
    //This class has methods for entity manipulation
    private ShopHibernate shopHibernate;
    //I need to know which user is selected
    private User user;
// user text input
    @FXML
    public TextField managerIdInput;
    public TextField managerLoginInput;
    public TextField managerNameInput;
    public TextField managerSurnameInput;
    public TextField userIdInput;
    public TextField userLoginInput;
    public TextField userNameInput;
    public TextField userSurnameInput;
    //private final ObservableList<ManagerTableParameters> data = FXCollections.observableArrayList();
    //private final ObservableList<CustomerTableParameters> datacust = FXCollections.observableArrayList();


    private GenericHibernate genericHibernate;

    //Kai klasė implements Initializable, implementuojam šį metodą. Jis suteikia galimybę mums prieiti prie laukų iki jie bus sugeneruoti
    @Override
    public void initialize(URL location, ResourceBundle resources) {
        productPackagingField.getItems().addAll(ProductPackaging.values());
        icecreamTypeField.getItems().addAll(IcecreamType.values());
        warehouseCityField.getItems().addAll(City.values());

        //Reikia likusius stulpelius pasibaigti
        managerTable.setEditable(true);
        //setCellValueFactory tik atvaizduos jei gerai aprasem
        managerColId.setCellValueFactory(new PropertyValueFactory<>("id"));
        managerColLogin.setCellValueFactory(new PropertyValueFactory<>("login"));
        managerColSurname.setCellValueFactory(new PropertyValueFactory<>("surname"));
        managerColPassword.setCellValueFactory(new PropertyValueFactory<>("password"));
        managerColName.setCellFactory(TextFieldTableCell.forTableColumn());
        managerColName.setOnEditCommit(event -> {
            event.getTableView().getItems().get(event.getTablePosition().getRow()).setName(event.getNewValue());
            Manager manager = shopHibernate.getEntityById(Manager.class, event.getTableView().getItems().get(event.getTablePosition().getRow()).getId());
            manager.setName(event.getNewValue());
            shopHibernate.update(manager);
        });
        managerColName.setCellValueFactory(new PropertyValueFactory<>("name"));
        //This portion of the code is responsible for generating a graphic element (button) in a cell
        Callback<TableColumn<ManagerTableParameters, Void>, TableCell<ManagerTableParameters, Void>> callback = param -> {
            final TableCell<ManagerTableParameters, Void> cell = new TableCell<>() {
                private final Button deleteButton = new Button("Delete");

                {
                    deleteButton.setOnAction(event -> {
                        ManagerTableParameters row = getTableView().getItems().get(getIndex());
                        shopHibernate.delete(Manager.class, row.getId());
                    });
                }

                @Override
                protected void updateItem(Void item, boolean empty) {
                    super.updateItem(item, empty);
                    if (empty) {
                        setGraphic(null);
                    } else {
                        setGraphic(deleteButton);
                    }
                }
            };
            return cell;
        };
        managerdummyCol.setCellFactory(callback);
        //TODO complete Customer TableView
        customerTable.setEditable(true);
        customerColId.setCellValueFactory(new PropertyValueFactory<>("id"));
        customerColLogin.setCellValueFactory(new PropertyValueFactory<>("login"));
        customerColName.setCellValueFactory(new PropertyValueFactory<>("name"));
        customerColSurname.setCellValueFactory(new PropertyValueFactory<>("surname"));
        customerColPassword.setCellValueFactory(new PropertyValueFactory<>("password"));
        customerColName.setCellFactory(TextFieldTableCell.forTableColumn());
        customerColName.setOnEditCommit(event -> {
            event.getTableView().getItems().get(event.getTablePosition().getRow()).setName(event.getNewValue());
            Customer customer = shopHibernate.getEntityById(Customer.class, event.getTableView().getItems().get(event.getTablePosition().getRow()).getId());
            customer.setName(event.getNewValue());
            shopHibernate.update(customer);
        });
        customerColName.setCellValueFactory(new PropertyValueFactory<>("name"));
        Callback<TableColumn<CustomerTableParameters, Void>, TableCell<CustomerTableParameters, Void>> callback2 = param -> {

            final TableCell<CustomerTableParameters, Void> cell = new TableCell<>() {
                private final Button deleteButton = new Button("Delete");

                {
                    deleteButton.setOnAction(event -> {
                        CustomerTableParameters row = getTableView().getItems().get(getIndex());
                        shopHibernate.delete(Customer.class, row.getId());
                    });
                }

                @Override
                protected void updateItem(Void item, boolean empty) {
                    super.updateItem(item, empty);
                    if (empty) {
                        setGraphic(null);
                    } else {
                        setGraphic(deleteButton);
                    }
                }

            };
            return cell;
        };
        customerdummyCol.setCellFactory(callback2);
    }
        //viska i customer


    public void setData(EntityManagerFactory entityManagerFactory, User user) {
        this.entityManagerFactory = entityManagerFactory;
        this.user = user;
        this.shopHibernate = new ShopHibernate( entityManagerFactory);
        loadTabData();
        setCustomerView();
        fillManagerTable();
        fillCustomerTable();
        fillOrdersTable();
    }

    private void setCustomerView() {
        //Customer should not have any access or knowledge about tabs that are intended for Managers/Admins
        if (user instanceof Customer) {
            //You could simply disable tabs, but it is better to not render them
            tabPane.getTabs().remove(usersTab);
            tabPane.getTabs().remove(productsTab);
            tabPane.getTabs().remove(warehousesTab);
        } else if (!((Manager) user).isAdmin()) {
            //TODO disable fields or functions that simple managers should not be able to access
            tabPane.getTabs().remove(warehousesTab);
            managerTable.setEditable(false);
            customerTable.setEditable(false);
        }
    }

    //<editor-fold desc="Logic for User Tab">
    private void fillManagerTable() {
        //get all records from the database for Manager TableView
        List<Manager> managers = shopHibernate.getAllRecords(Manager.class);
        for (Manager m : managers) {
            ManagerTableParameters managerTableParameters = new ManagerTableParameters();
            managerTableParameters.setId(m.getId());
            managerTableParameters.setLogin(m.getLogin());
            managerTableParameters.setName(m.getName());
            managerTableParameters.setSurname(m.getSurname());
            managerTableParameters.setPassword(m.getPassword());
            //TODO complete remaining columns
            datamanager.add(managerTableParameters);
        }
        managerTable.setItems(datamanager);
    }
    private void fillCustomerTable() {
        List<Customer> customers = shopHibernate.getAllRecords(Customer.class);
        for (Customer m : customers) {
            CustomerTableParameters customerTableParameters = new CustomerTableParameters();
            customerTableParameters.setId(m.getId());
            customerTableParameters.setLogin(m.getLogin());
            customerTableParameters.setName(m.getName());
            customerTableParameters.setSurname(m.getSurname());
            customerTableParameters.setPassword(m.getPassword());
            datacust.add(customerTableParameters);
        }
        customerTable.setItems(datacust);
    }
    public void fillOrdersTable() {
        ordersTableView.setEditable(true);
        //setCellValueFactory allows to display the data
        cartColId.setCellValueFactory(new PropertyValueFactory<>("id"));

        cartColTitle.setCellFactory(TextFieldTableCell.forTableColumn());
        cartColTitle.setOnEditCommit(event -> {
            //event - click on cell
            //event.getNewValue - when we click on cell and enter new value
            //event knows which table was selected, which row was selected and which cell was changed
            event.getTableView().getItems().get(event.getTablePosition().getRow()).setTitle(event.getNewValue());
            //Before updating, get the latest version from database
            Product product = shopHibernate.getEntityById(Product.class, event.getTableView().getItems().get(event.getTablePosition().getRow()).getId());
            product.setTitle(event.getNewValue());
            shopHibernate.update(product);
        });
        cartColTitle.setCellValueFactory(new PropertyValueFactory<>("title"));
        cartColType.setCellValueFactory(new PropertyValueFactory<>("type"));
        cartColColour.setCellValueFactory(new PropertyValueFactory<>("colour"));
        cartColPrice.setCellValueFactory(new PropertyValueFactory<>("price"));
    }


    //Metodas, kuris kviečiamas paspaudus mygtuką Add
    public void createRecord() {
        try {
            if (productFruitsRadio.isSelected()) {
                Fruits fruits = new Fruits(productTitleField.getText(),
                        productTypeField.getText(),
                        productColourField.getText(),
                        productDescriptionField.getText(),
                        Integer.parseInt(productQuantityField.getText()),
                        Float.parseFloat(productWeightField.getText()),
                        Float.parseFloat(productPriceField.getText()),
                        productPlantDateField.getValue(),
                        productValidTillField.getValue());
                shopHibernate.create(fruits);
                //Kai turėsime duomenų bazę, šiame žyngsnyje tą objekto info išsaugosime db ir tik tada atvaizduosime
                productAdminList.getItems().add(fruits); //Kol kas tiesiog atvaizduoju sukurtą objektą ListView elemente
            } else if (productVegetablesRadio.isSelected()) {
                //Čia jei pasirinktas produktas sėklos, susirenku info iš tų laukų, kurie reikalingi Seed objekto kūrimui
                Vegetables vegetables = new Vegetables(productTitleField.getText(),
                        productDescriptionField.getText(),
                        productTypeField.getText(),
                        productColourField.getText(),
                        Integer.parseInt(productQuantityField.getText()),
                        Float.parseFloat(productWeightField.getText()),
                        Float.parseFloat(productPriceField.getText()),
                        productFarmField.getText(),
                        productSeedPickDate.getValue(),
                        productPackagingField.getValue());
                shopHibernate.create(vegetables);
                productAdminList.getItems().add(vegetables);
            } else {
                //O čia kas liko - Tool
                IceCream iceCream = new IceCream(productTitleField.getText(),
                        productDescriptionField.getText(),
                        productTypeField.getText(),
                        productColourField.getText(),
                        Integer.parseInt(productQuantityField.getText()),
                        Float.parseFloat(productWeightField.getText()),
                        Float.parseFloat(productPriceField.getText()),
                        productManufacturerField.getText());
                shopHibernate.create(iceCream);
                productAdminList.getItems().add(iceCream);
            }
            productAdminList.getItems().clear();
            productAdminList.getItems().addAll(shopHibernate.getAllRecords(Product.class));
            clearAllInfo();
        } catch (Exception e) {
            FxUtils.generateAlert(Alert.AlertType.INFORMATION, "Error", "Not all tabs filled.");
        }
        //Tikrinam ar pasirinktas augalas, jei taip, kuriam Plant objektą, susirinkdami info iš laukų, kurie reikalingi Plant
    }

    public void updateRecord() {
        Product product = productAdminList.getSelectionModel().getSelectedItem();
        if (product instanceof Fruits fruits) {
            product.setTitle(productTitleField.getText());
            //productDescriptionField.setText(plant.getDescription());
            fruits.setDescription(productDescriptionField.getText());
            shopHibernate.update(fruits);
        } else if (product instanceof Vegetables vegetables) {
            //TODO complete for remaining product types
            product.setTitle(productTitleField.getText());
            vegetables.setDescription(productDescriptionField.getText());
            shopHibernate.update(vegetables);
        } else if (product instanceof IceCream iceCream) {
            //TODO complete for remaining product types
            product.setTitle(productTitleField.getText());
            iceCream.setDescription(productDescriptionField.getText());
            shopHibernate.update(iceCream);
        }
        clearAllInfo();
    }

    //Kviečiamas delete mygtuko paspaudimo metu, ištrinam iš sąrašo
    public void deleteRecord() {
        Product product = productAdminList.getSelectionModel().getSelectedItem();
        if(product!=null){
            shopHibernate.delete(Product.class,product.getId());
        }
        productAdminList.getItems().remove(product);
        productAdminList.getItems().clear();
        productAdminList.getItems().addAll(shopHibernate.getAllRecords(Product.class));
        clearAllInfo();
    }
    //public void createUser(ActionEvent event) {
       // User user = new User(Integer.parseInt(userIdInput.getText(),
              //userLoginInput.getText(),
               // userNameInput.getText(),
               // userSurnameInput.getText());
      //  ObservableList<User> users = customerTable.getItems();
       // users.add(user);
        //customerTable.setItems(users);
        //genericHibernate.create(user);
       // customerTable.getItems().add(user);

   // }
    public void updateUser() {

    }
    public void removeUser() {

    }
    //Čia metodas, kuris iškviečiamas paspaudus ant bet kurio radio button
    public void disableFields() {
        //vienus laukus enable'inu, o kitus disable'inu. Yra dar metodas setVisible(), jei norit iš viso neatvaizduoti elemento
        if (productFruitsRadio.isSelected()) {
            productFarmField.setDisable(true);
            productSeedPickDate.setDisable(true);
            productPackagingField.setDisable(false);
            productManufacturerField.setDisable(true);
            productPlantDateField.setDisable(false);
            productValidTillField.setDisable(false);
            productColourField.setDisable(false);
            productTypeField.setDisable(false);
            productPriceField.setDisable(false);
            icecreamTypeField.setDisable(true);
        } else if (productVegetablesRadio.isSelected()) {
            productFarmField.setDisable(false);
            productSeedPickDate.setDisable(false);
            productPackagingField.setDisable(false);
            productManufacturerField.setDisable(true);
            productPlantDateField.setDisable(true);
            productValidTillField.setDisable(false);
            productColourField.setDisable(false);
            productTypeField.setDisable(false);
            productPriceField.setDisable(false);
            icecreamTypeField.setDisable(true);
        } else {
            productManufacturerField.setDisable(false);
            productFarmField.setDisable(true);
            productSeedPickDate.setDisable(true);
            productPackagingField.setDisable(false);
            productValidTillField.setDisable(false);
            productColourField.setDisable(false);
            productTypeField.setDisable(true);
            productPriceField.setDisable(false);
            icecreamTypeField.setDisable(false);
        }
    }

    //Šis metodas iškviečiamas paspaudus ant ListView elemento, kuriame atvaizduojame visus produktus
    //Jis uzpildo laukus su objekto info i laukus ir leidzia mums ja patogiai koreguoti
    public void loadProductData() {
        //ListView elementas turi getSelectionModel().getSelectedItem(), jei norim nustatyti kurį įrašą pasirinko
        Product product = productAdminList.getSelectionModel().getSelectedItem();

        //Kadangi ListView<Product> saugo Product t.y. ten kur parent klase, galime saugoti vaikines klases objektus
        //Bet tokiu atveju negalim pasiekti atributu ir metodu vaikinese klasese
        //Tai galim patikrinti su instanceof koks ten vaikas ir padaryti type casting
        if (product instanceof Fruits fruits) {
            productTitleField.setText(fruits.getTitle());
            productDescriptionField.setText(fruits.getDescription());
            productQuantityField.setText(String.valueOf(fruits.getQty()));
            productWeightField.setText(String.valueOf(fruits.getWeight()));

        } else if (product instanceof Vegetables vegetables) {
            productTitleField.setText(vegetables.getTitle());
            productDescriptionField.setText(vegetables.getDescription());
            productQuantityField.setText(String.valueOf(vegetables.getQty()));
            productWeightField.setText(String.valueOf(vegetables.getWeight()));
            productFarmField.setText(vegetables.getFarm());
            productSeedPickDate.setValue(vegetables.getCollectDate());
            productPackagingField.setValue(vegetables.getProductPackaging());
        } else if (product instanceof IceCream iceCream) {
            productTitleField.setText(iceCream.getTitle());
            productDescriptionField.setText(iceCream.getDescription());
            productQuantityField.setText(String.valueOf(iceCream.getQty()));
            productWeightField.setText(String.valueOf(iceCream.getWeight()));
            productManufacturerField.setText(iceCream.getManufacturer());
        }
    }

    public void loadProductReviewForm() throws IOException {
        //Surink resources: fxml, constoller, vaizdo, grafine, stiliaus
        FXMLLoader fxmlLoader = new FXMLLoader(HelloApplication.class.getResource("product-review.fxml"));
        //Uzkrauk resursus. Be sio zingsnio as nepasieksiu kontrolerio ar kitu resursu
        Parent parent = fxmlLoader.load();

        ProductReview productReview = fxmlLoader.getController();
        //Formos nezino viena apie kita, vadinasi turiu perduoti connection ir siuo metu prisijungusi vartotoja
        //Forms do not know about each other, therefore I must pass info between them
        productReview.setData(entityManagerFactory, user);
        //Sukuriu dar viena langa
        Stage stage = new Stage();
        Scene scene = new Scene(parent);
        FxUtils.setStageParameters(stage, scene, true);
    }
    //CTRL+ALT+T editor fold
    //<editor-fold desc="Shop functions">
    public void removeFromCart() {
        Product product = myCartItems.getSelectionModel().getSelectedItem();
        shopProducts.getItems().add(product);
        myCartItems.getItems().remove(product);
    }

    public void addToCart() {
        Product product = shopProducts.getSelectionModel().getSelectedItem();
        myCartItems.getItems().add(product);
        shopProducts.getItems().remove(product);
    }

    public void buyItems() {
        ObservableList<Product> temp = myCartItems.getItems();
        if (!temp.isEmpty() && shopHibernate.getCustomerByCredentials(user.getLogin(), user.getPassword()) != null) {
            shopHibernate.createCart(myCartItems.getItems(), user);
            myCartItems.getItems().clear();
        }
        //</editor-fold>
    }
    public void deleteOrder() {
        Cart cart = ordersListView.getSelectionModel().getSelectedItem();
        ordersListView.getItems().remove(cart);
        //TODO neveikia deleteCart
        shopHibernate.deleteCart(cart.getId());

    }
    public void loadTabData() {
        if (shopTab.isSelected()) {
            shopProducts.getItems().addAll(shopHibernate.loadAvailableProducts());
        } else if (usersTab.isSelected()) {
            fillManagerTable();
            //TODO complete Customer TableView
            //fillCustomerTable();
        }
        //TODO fill only when the tab is clicked
    }
    @FXML
    private void loadCartData() {
        ordersTableView.getItems().clear();
        Cart cart = ordersListView.getSelectionModel().getSelectedItem();
        if (cart != null) {
            cart = shopHibernate.getEntityById(Cart.class, cart.getId());
            List<Product> products = cart.getProductList();
            for (Product m : products) {
                CartTableParameters cartTableParameters = new CartTableParameters();
                cartTableParameters.setId(m.getId());
                cartTableParameters.setTitle(m.getTitle());
                cartTableParameters.setType(m.getType());
                cartTableParameters.setColour(m.getColour());
                cartTableParameters.setPrice(m.getPrice());
                datacart.add(cartTableParameters);
            }
            ordersTableView.setItems(datacart);
        }
    }

    public void setData(EntityManagerFactory entityManagerFactory) {

    }

    public void createUser(ActionEvent actionEvent) {

    }
    public void createWarehouse() {
        Warehouse warehouse = new Warehouse(warehouseAddressField.getText(),
                warehouseCityField.getSelectionModel().getSelectedItem());
        shopHibernate.create(warehouse);
        warehouseList.getItems().clear();
        warehouseList.getItems().addAll(shopHibernate.getAllRecords(Warehouse.class));
    }

    public void updateWarehouse(ActionEvent actionEvent) {
        Warehouse warehouse = (warehouseList.getSelectionModel().getSelectedItem());
            warehouse.setCity(warehouseCityField.getSelectionModel().getSelectedItem());
            warehouse.setAddress(warehouseAddressField.getText());
            shopHibernate.update(warehouse);
    }

    public void deleteWarehouse(ActionEvent actionEvent) {
        Warehouse warehouse = warehouseList.getSelectionModel().getSelectedItem();
        if(warehouse!=null){
            shopHibernate.delete(Warehouse.class,warehouse.getId());
        }
        warehouseList.getItems().remove(warehouse);
        warehouseList.getItems().clear();
        warehouseList.getItems().addAll(shopHibernate.getAllRecords(Warehouse.class));
    }
    public void loadTabs(Event actionEvent) {
        if (shopTab.isSelected()) {
            shopProducts.getItems().clear();
            shopProducts.getItems().addAll(shopHibernate.loadAvailableProducts());
        }
        if (productsTab.isSelected()) {
            productAdminList.getItems().clear();
            productAdminList.getItems().addAll(shopHibernate.loadAvailableProducts());
        }
        if (usersTab.isSelected()) {
            managerTable.getItems().clear();
            customerTable.getItems().clear();
            fillManagerTable();
            fillCustomerTable();
        }
        if (ordersTab.isSelected()) {
            ordersListView.getItems().clear();
            ordersListView.getItems().addAll(shopHibernate.getAvailableCarts(user));

        }
        if (warehousesTab.isSelected()) {
            warehouseList.getItems().clear();
            warehouseList.getItems().addAll(shopHibernate.getAllRecords(Warehouse.class));
        }
    }
    public void openRegistration(Event ActionEvent) throws IOException {
        FXMLLoader fxmlLoader = new FXMLLoader(HelloApplication.class.getResource("registration.fxml"));
        Parent parent = fxmlLoader.load();
        RegistrationController registration = fxmlLoader.getController();
        registration.setData(entityManagerFactory, true);
        Stage stage = new Stage();
        Scene scene = new Scene(parent);
        stage.setScene(scene);
        stage.initModality(Modality.APPLICATION_MODAL);
        stage.showAndWait();
        managerTable.getItems().clear();
        fillManagerTable();
        customerTable.getItems().clear();
        fillCustomerTable();
    }


    public void writeReview() throws IOException {
        FXMLLoader fxmlLoader = new FXMLLoader(HelloApplication.class.getResource("cartReviewForm.fxml"));
        Parent parent = fxmlLoader.load();
        //Access controller of main window. Each form has its own controller, so make sure that you make no mistake here
        CartReviewForm cartReviewForm = fxmlLoader.getController();
        Cart cart = ordersListView.getSelectionModel().getSelectedItem();
        cartReviewForm.setData(entityManagerFactory,cart);
        Stage stage = new Stage();
        Scene scene = new Scene(parent);
        stage.setScene(scene);
        stage.initModality(Modality.APPLICATION_MODAL);
        stage.show();
    }

    public void filterList() {
        ordersListView.getItems().clear();
        Customer customer = null;
        Manager manager = null;
        if(!customerId.getText().trim().isEmpty()){
            customer = shopHibernate.getEntityById(Customer.class,Integer.parseInt(customerId.getText()));
        }
        if(!managerId.getText().trim().isEmpty())
        {
            manager = shopHibernate.getEntityById(Manager.class,Integer.parseInt(managerId.getText()));
        }
        ordersListView.getItems().addAll(shopHibernate.filterOrders(dateFrom.getValue(),dateTo.getValue(),customer,manager));

    }
    private void clearAllInfo() {
        productTitleField.setText("");
        productTypeField.setText("");
        productColourField.setText("");
        productDescriptionField.setText("");
        productPriceField.setText("");
        productQuantityField.setText("");
        productFarmField.setText("");
        productWeightField.setText("");
        productManufacturerField.setText("");
        productPackagingField.getSelectionModel().clearSelection();
        icecreamTypeField.getSelectionModel().clearSelection();
    }
}


//    public void deleteCart() {
//        shopHibernate.deleteCart();
//    }
    //</editor-fold>

