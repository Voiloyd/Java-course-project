package com.javacourse.courseprojectfx.hibernate;

import com.javacourse.courseprojectfx.model.*;
import jakarta.persistence.EntityManager;
import jakarta.persistence.EntityManagerFactory;
import jakarta.persistence.NoResultException;
import jakarta.persistence.Query;
import jakarta.persistence.criteria.CriteriaBuilder;
import jakarta.persistence.criteria.CriteriaQuery;
import jakarta.persistence.criteria.Predicate;
import jakarta.persistence.criteria.Root;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class ShopHibernate extends GenericHibernate {
    public ShopHibernate(EntityManagerFactory entityManagerFactory) {
        super(entityManagerFactory);
    }

    //This is a custom method for creating cart. It is more complicated, because cart must jave  abuyer assigned,
    //products must be assigned to cart
    public void createCart(List<Product> products, User user) {
        //All must happen within the same transaction
        try {
            entityManager = getEntityManager();
            entityManager.getTransaction().begin();
            //First get the customer
            Customer buyer = entityManager.find(Customer.class, user.getId());
            //Then we go through the objects that user wants to buy
            Cart cart = new Cart(new ArrayList<>(), buyer);
            for (Product p : products) {
                Product product = entityManager.find(Product.class, p.getId());
                //Assign cart to product and product to cart. So that data would be properly stored in db
                product.setCart(cart);
                cart.getProductList().add(product);
            }
            buyer.getMyCarts().add(cart);
            //Update buyer, we have cascade all, so this new cart will be inserted and ids assigned
            entityManager.merge(buyer);
            entityManager.getTransaction().commit();
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            if (entityManager != null) entityManager.close();
        }
    }

    public void deleteCart(int id) {
        try {
            entityManager = getEntityManager();
            entityManager.getTransaction().begin();

            //Get the cart that we plan to delete
            var cart = entityManager.find(Cart.class, id);

            if(cart.getCustomer()!=null){
                Customer customer = entityManager.find(Customer.class, cart.getCustomer().getId());
                //remove this cart from customer cart list
                customer.getMyCarts().remove(cart);
                //update these changes within this transaction
                entityManager.merge(customer);
            }
            if(cart.getManager()!=null){
                Manager manager = entityManager.find(Manager.class, cart.getManager().getId());
                manager.getMyManagedCarts().remove(cart);
                entityManager.merge(manager);
            }
            List<Product>products = cart.getProductList();
            for (Product p: products){
                Product product = entityManager.find(Product.class, p.getId());
                product.setCart(null);
            }
            cart.getProductList().clear();
            entityManager.remove(cart);

            entityManager.getTransaction().commit();
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            if (entityManager != null) entityManager.close();
        }
    }

    public Manager getManagerByCredentials(String login, String password) {
        EntityManager em = getEntityManager();
        try {
            CriteriaBuilder cb = em.getCriteriaBuilder();
            CriteriaQuery<Manager> query = cb.createQuery(Manager.class);
            Root<Manager> root = query.from(Manager.class);
            query.select(root).where(cb.and(cb.like(root.get("login"), login), cb.like(root.get("password"), password)));
            Query q;

            q = em.createQuery(query);
            return (Manager) q.getSingleResult();
        } catch (NoResultException e) {
            return null;
        } finally {
            if (em != null) em.close();
        }
    }

    public Customer getCustomerByCredentials(String login, String password) {
        EntityManager em = getEntityManager();
        try {
            CriteriaBuilder cb = em.getCriteriaBuilder();
            CriteriaQuery<Customer> query = cb.createQuery(Customer.class);
            Root<Customer> root = query.from(Customer.class);
            query.select(root).where(cb.and(cb.like(root.get("login"), login), cb.like(root.get("password"), password)));
            Query q;

            q = em.createQuery(query);
            return (Customer) q.getSingleResult();
        } catch (NoResultException e) {
            return null;
        } finally {
            if (em != null) em.close();
        }
    }
    public User getUserByCredentials(String login, String password) {
        EntityManager em = getEntityManager();
        try {
            CriteriaBuilder cb = em.getCriteriaBuilder();
            CriteriaQuery<User> query = cb.createQuery(User.class);
            Root<User> root = query.from(User.class);
            query.select(root).where(cb.and(cb.like(root.get("login"), login), cb.like(root.get("password"), password)));
            Query q;

            q = em.createQuery(query);
            return (User) q.getSingleResult();
        } catch (NoResultException e) {
            return null;
        } finally {
            if (em != null) em.close();
        }
    }
    public void deleteComment(int id) {
        EntityManager em = getEntityManager();
        try {
            em.getTransaction().begin();
            var comment = em.find(Comment.class, id);
            if(comment.getReview()!=null){
                Product product = em.find(Product.class, comment.getReview().getId());
                product.getComments().remove(comment);
                em.merge(product);
            }

            User user = getUserByCredentials(comment.getOwner().getLogin(), comment.getOwner().getPassword());
            user.getComments().remove(comment);
            em.merge(user);

            comment.getReplies().clear();
            em.remove(comment);

            em.getTransaction().commit();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
    public List<Cart> getAvailableCarts(User user){
        List<Cart> record =getAllRecords(Cart.class);
        List<Cart> answer=new ArrayList<>();
        for(Cart rc: record){
            Cart cart = getEntityById(Cart.class,rc.getId());
            if(cart.getCustomer().getId()==user.getId() || getManagerByCredentials(user.getLogin(),user.getPassword())!=null )
                answer.add(cart);
        }
        return answer;
    }
    public List<Cart> filterOrders(LocalDate dateFrom, LocalDate dateTo, Customer customer, Manager manager) {
        EntityManager em = getEntityManager();
        try {
            CriteriaBuilder cb = em.getCriteriaBuilder();
            CriteriaQuery<Cart> query = cb.createQuery(Cart.class);
            Root<Cart> root = query.from(Cart.class);
            Predicate predicate = cb.conjunction(); // Initialize predicate as a conjunction (AND)
            // Add conditions based on the provided parameters
            if (dateFrom != null) {
                predicate = cb.and(predicate, cb.greaterThan(root.get("dateCreated"), dateFrom));
            }
            if (dateTo != null) {
                predicate = cb.and(predicate, cb.lessThan(root.get("dateCreated"), dateTo));
            }
            if (customer != null) {
                predicate = cb.and(predicate, cb.equal(root.get("customer"), customer));
            }
            if (manager != null) {
                predicate = cb.and(predicate, cb.equal(root.get("manager"), manager));
            }

            query.select(root).where(predicate); // Apply the predicate to the query

            jakarta.persistence.Query q = em.createQuery(query);
            return q.getResultList();
        } catch (NoResultException e) {
            return Collections.emptyList(); // Return an empty list if no results are found
        } finally {
            if (em != null) em.close();
        }
    }
    public List<Product> loadAvailableProducts(){
        EntityManager em = getEntityManager();
        try {
            CriteriaBuilder cb = em.getCriteriaBuilder();
            CriteriaQuery<Product> query = cb.createQuery(Product.class);
            Root<Product> root = query.from(Product.class);
            query.select(root).where(cb.isNull(root.get("cart")));
            Query q;

            q = em.createQuery(query);
            return q.getResultList();
        } catch (NoResultException e) {
            return null;
        } finally {
            if (em != null) em.close();
        }
    }
    public void createComment(String commentBody, Cart cart){
        try {
            entityManager = getEntityManager();
            entityManager.getTransaction().begin();

            Comment comment = new Comment();
            comment.setCommentBody(commentBody);
            comment.setChat(cart);
            cart.getChat().add(comment);
            entityManager.merge(cart);

            entityManager.getTransaction().commit();
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            if (entityManager != null) entityManager.close();
        }
    }
}
