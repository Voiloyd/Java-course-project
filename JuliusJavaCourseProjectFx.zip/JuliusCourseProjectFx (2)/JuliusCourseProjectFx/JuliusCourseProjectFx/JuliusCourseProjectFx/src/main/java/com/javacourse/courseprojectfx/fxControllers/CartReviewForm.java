package com.javacourse.courseprojectfx.fxControllers;

import jakarta.persistence.EntityManager;
import jakarta.persistence.EntityManagerFactory;
import javafx.event.ActionEvent;
import javafx.scene.control.ListView;
import javafx.scene.control.TextArea;
import com.javacourse.courseprojectfx.hibernate.ShopHibernate;
import com.javacourse.courseprojectfx.model.Cart;
import com.javacourse.courseprojectfx.model.Comment;
import com.javacourse.courseprojectfx.model.Product;

import java.util.List;

public class CartReviewForm {

    public ListView<Comment> chatListView;
    public TextArea commentTextView;
    private EntityManagerFactory entityManagerFactory;
    private ShopHibernate shopHibernate;
    private Cart cart;
    public void setData(EntityManagerFactory entityManagerFactory, Cart cart){
        this.entityManagerFactory = entityManagerFactory;
        this.shopHibernate = new ShopHibernate(entityManagerFactory);
        this.cart=cart;
        chatListView.getItems().addAll(cart.getChat());
    }

    public void commentCart(ActionEvent actionEvent) {
        shopHibernate.createComment(commentTextView.getText(), cart);
        cart=shopHibernate.getEntityById(Cart.class,cart.getId());
        chatListView.getItems().clear();
        chatListView.getItems().addAll(cart.getChat());
    }
}
