package com.javacourse.courseprojectfx.fxControllers.tableParameters;

import javafx.beans.property.SimpleIntegerProperty;
import javafx.beans.property.SimpleStringProperty;

public class CustomerTableParameters extends UserTableParameters{
    public CustomerTableParameters() {
    }

    public CustomerTableParameters(SimpleIntegerProperty id, SimpleStringProperty login, SimpleStringProperty name, SimpleStringProperty surname, SimpleStringProperty password) {
        super(id, login, name, surname, password);
    }
}
