package com.javacourse.courseprojectfx.model;


import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import org.hibernate.annotations.LazyCollection;
import org.hibernate.annotations.LazyCollectionOption;

import java.util.List;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Entity
public class Comment {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private int id;
    private String commentTitle;
    private String commentBody;
    @ManyToOne
    private User owner;
    @OneToMany(mappedBy = "parentComment", cascade = CascadeType.ALL, orphanRemoval = true)
    @LazyCollection(LazyCollectionOption.FALSE)
    private List<Comment> replies;
    @ManyToOne
    private Comment parentComment;
    @ManyToOne
    private Product review;
    private float rating;
    @ManyToOne
    private Cart chat;
    public Comment(String commentTitle, String commentBody, double rating, User user, Product review) {
        this.commentTitle = commentTitle;
        this.commentBody = commentBody;
        this.rating = (float) rating;
        this.owner = user;
        this.review = review;
    }

    public Comment(String commentTitle, String commentBody, User owner, Comment parentComment) {
        this.commentTitle = commentTitle;
        this.commentBody = commentBody;
        this.owner = owner;
        this.parentComment = parentComment;
    }
    @Override
    public String toString() {
        return "id: " + id + " title = " + commentTitle +" : " +commentBody;
    }
}
