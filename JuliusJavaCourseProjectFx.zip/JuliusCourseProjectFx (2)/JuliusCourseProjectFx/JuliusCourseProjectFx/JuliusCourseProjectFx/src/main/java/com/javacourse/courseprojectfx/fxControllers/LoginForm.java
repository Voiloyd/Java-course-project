package com.javacourse.courseprojectfx.fxControllers;

import jakarta.persistence.EntityManagerFactory;
import jakarta.persistence.Persistence;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.TextField;
import javafx.stage.Modality;
import javafx.stage.Stage;
import com.javacourse.courseprojectfx.HelloApplication;
import com.javacourse.courseprojectfx.hibernate.ShopHibernate;
import com.javacourse.courseprojectfx.model.PasswordHash;
import com.javacourse.courseprojectfx.model.User;

import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;

public class LoginForm implements Initializable {

    @FXML
    public TextField passwordField;
    @FXML
    public TextField loginField;
    private EntityManagerFactory entityManagerFactory;
    @Override
    public void initialize(URL location, ResourceBundle resources) {
        entityManagerFactory = Persistence.createEntityManagerFactory("Shop");
    }
    public void validateAndLoadMain() throws IOException {
        String password = PasswordHash.hashPassword(passwordField.getText());
        ShopHibernate hibernateShop = new ShopHibernate(entityManagerFactory);
        User user = hibernateShop.getUserByCredentials(loginField.getText(),password);
        if(user!=null){
            FXMLLoader fxmlLoader = new FXMLLoader(HelloApplication.class.getResource("main-window.fxml"));
            Parent parent = fxmlLoader.load();
            MainWindow mainWindow = fxmlLoader.getController();
            mainWindow.setData(entityManagerFactory,user);
            Stage stage = (Stage) loginField.getScene().getWindow();
            Scene scene = new Scene(parent);
            stage.setTitle("MAXIMA");
            stage.setScene(scene);
            stage.show();
        }
    }

    public void openRegistration() throws IOException {
        FXMLLoader fxmlLoader = new FXMLLoader(HelloApplication.class.getResource("registration.fxml"));
        Parent parent = fxmlLoader.load();
        //Access controller of main window. Each form has its own controller, so make sure that you make no mistake here
        RegistrationController registrationController= fxmlLoader.getController();
        registrationController.setData(entityManagerFactory, true);
        Stage stage = new Stage();
        Scene scene = new Scene(parent);
        stage.setScene(scene);
        stage.initModality(Modality.APPLICATION_MODAL);
        stage.show();
    }


}
